import { Component } from "react";
import React from "react";

class Input extends Component {
  state = {
    text: "",
    warning: false
  };

  onChange = (e) => {
    this.setState((prevState) => ({
      text: e.target.value,
      warning: false
    }));
  };

  onSubmit = (e) => {
    e.preventDefault();
    if (this.state.text.trim().length === 0) {
      this.setState({ warning: true });
    } else {
      this.setState({ text: "", warning: false });
      this.props.onSendMessage(this.state.text);
    }
  };

  render() {
    return (
      <div className="Input">
        <form onSubmit={this.onSubmit}>
          <div className="input-container">
            <input
              onChange={this.onChange}
              value={this.state.text}
              type="text"
              placeholder="Enter your message and press ENTER"
              autoFocus={true}
              className={this.state.warning ? "input-warning" : ""}
            />
            {this.state.warning && (
              <div className="warning-message">Please enter a message</div>
            )}
          </div>
          <button className="third">Send</button>
        </form>
      </div>
    );
  }
}

export default Input;
